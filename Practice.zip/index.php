<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content=" Awesome PortPolio Templet" >
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <title>Libas - Awesome PortPolio Templet</title>
    <link rel="shortcut icon" type="image/x-icon" href="Resurce/img/favicon.png">
 
    <link href="https://fonts.googleapis.com/css2?family=Titillium+Web:wght@300;400;600;700&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/317ba1fa84.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="Vendors/css/normalize.css">
<link rel="stylesheet" href="Vendors/css/grid.css"> 
    <link rel="stylesheet" href="Resurce/Css/style.css">
    <link rel="stylesheet" href="Resurce/Css/responsive.css">
   
</head>
<body>
  
<!--HEADER SECTION-->
 <header id="home">
     <nav>
         <div class="row">
             <a href="home" >
                 <img src="Resurce/img/logo.png" class="logo" alt="Cuda">
             </a>
             <ul class="main-nav">
                 <li class="active"><a  href="#home" >Home</a></li>
                 <li><a href="#service" >Service</a></li>
                 <li><a href="#Team" >Team</a></li>
                 <li><a href="#skill" >Skill</a></li>
                 <li><a href="#PortFolio" >PortFolio</a></li>
                 <li><a href="#Testimonial" >Testimonial</a></li>
                 <li><a href="#Contact" >Contact</a></li>
                
             </ul>
                <div class="mobaile-menu">
                    <span style="color: #fff;" onclick="openNav()">&#9776;</span>
                    <div id="myNav" class="overlay" >
                        <a href="javascript:void()" onclick="closeNav()" class="closebtn">&times;</a>
                        <div class="overlay-content">
                                <a onclick="closeNav()" href="#home" >Home</a>
                                <a onclick="closenNav()" href="#service" >Service</a>
                                <a onclick="closeNav()" href="#Team" >Team</a>
                                <a onclick="closeNav()" href="#skill" >Skill</a>
                                <a onclick="closeNav()" href="#PortFolio" >PortFolio</a>
                                <a onclick="closeNav()" href="#Testimonial" >Testimonial</a>
                                <a onclick="closeNav()" href="#Contact" >Contact</a>
                        </div>
                    </div>
                </div>
                 </div>
                  </nav>

             <div class="row">
                 <div class="text">
                     <h1>Hi there! We are the new kids on the block 
                        and we build awesome websites and mobile apps.</h1>
                        <a href="#Contact" class="btn btn-hero" >Work With Us</a>
                 </div>
             </div>
         
 </header>
 
 
 
 
 
<!--SECTION START-->
  
  <section class="section-start clearfix js--service-section" id="service">
     <div class="row">
         <h2>Services we provide</h2>
         <p class="textmart">
             We are working with both individuals and businesses from all over the globe 
             to create awesome websites and applications.

         </p>
     </div>
     <div class="row">
         <div class="col span_1_of_4 max">
            <img src="Resurce/img/flag.png" alt="Flag" class="service-icon">
            <h3>Branding</h3>
             <p>Lorem ipsum dolor sit amet, 
                consectetuer adipiscing elit, sed diam nonummy nibh.</p>
         </div> 
     </div>
     <div class="row">
         <div class="col span_1_of_4 max">
            <img src="Resurce/img/crayon.png" alt="Crayon" class="service-icon">
            <h3>Design</h3>
             <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem.hi lorem you good</p>
         </div>
     </div>
     <div class="row">
         <div class="col span_1_of_4 max">
            <img src="Resurce/img/gears.png" alt="Gears" class="service-icon">
            <h3>Development</h3>
             <p>At vero eos et accusamus et iusto odio dignissimos qui blanditiis praesentium.</p>
         </div>
     </div>
     <div class="row">
         <div class="col span_1_of_4 max">
            <img src="Resurce/img/rocket.png" alt="Roket" class="service-icon">
            <h3>ROCKET SCIENCE</h3>
             <p>Et harum quidem rerum est et expedita distinctio. Nam libero tempore.</p>
         </div>
     </div>
      
  </section>
  
<!--Section end-->
<!-- OURTEAM SECTION START-->
  <section class="team-section clearfix " id="Team">
      <div class="row">
          <h2>MEET OUR BEAUTIFUL TEAM</h2>
          <p>We are a small team of designers and developers, who help brands with big ideas.
            </p>
      </div>
     <div class="row">
         <div class="col span_1_of_4 max">
            <img src="Resurce/img/1.jpg" alt="ANNE HATHAWAY" class="teampic">
            <h3>ANNE HATHAWAY</h3>
            <span class="ceo">CEO / Marketing Guru</span>
            <p>Lorem ipsum dolor sit amet, 
            consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna.</p>
             <div class="social-link">
                 <ul>
                     <li><a href="#"><i class="fa-brands fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
                     <li><a href="#"><i class="fa-regular fa-envelope"></i></a></li>
                 </ul>
             </div>
         </div>
     </div>
     
     <div class="row">
         <div class="col span_1_of_4 max">
            <img src="Resurce/img/2.jpg" alt="Kate Upton" class="teampic">
            <h3>Kate Upton</h3>
            <span class="ceo">Creative Director</span>
            <p>Duis aute irure dolor in in voluptate velit esse cillum dolore fugiat nulla pariatur. Excepteur sint occaecat non diam proident.</p>
             <div class="social-link">
                 <ul>
                     <li><a href=https://facebook.com/codermoshiur><i class="fa-brands fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
                     <li><a href="#"><i class="fa-regular fa-envelope"></i></a></li>
                 </ul>
             </div>
         </div>
     </div>
     
     <div class="row">
         <div class="col span_1_of_4 max">
            <img src="Resurce/img/3.jpg" alt="Olivia Wilde" class="teampic">
            <h3>Kate Upton</h3>
            <span class="ceo">Lead Designer</span>
            <p>Nemo enim ipsam voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem nesciunt.</p>
             <div class="social-link">
                 <ul>
                     <li><a href=https://facebook.com/codermoshiur><i class="fa-brands fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
                     <li><a href="#"><i class="fa-regular fa-envelope"></i></a></li>
                 </ul>
             </div>
         </div>
     </div>
     
     <div class="row">
         <div class="col span_1_of_4 max">
            <img src="Resurce/img/4.jpg" alt="Ashley Greene" class="teampic">
            <h3>Kate Upton</h3>
            <span class="ceo">SEO / Developer</span>
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
             <div class="social-link">
                 <ul>
                     <li><a href=https://facebook.com/codermoshiur><i class="fa-brands fa-facebook"></i></a></li>
                     <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                     <li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
                     <li><a href="#"><i class="fa-regular fa-envelope"></i></a></li>
                 </ul>
             </div>
         </div>
     </div>
  </section>
  
<!-- SKILL SECTION START-->po

<section class="skill-section clearfix " id="skill">
    <div class="row">
        <h2>WE GOT SKILLS!</h2>
        <p class="textmart">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod 
            tempor incididunt ut labore et dolore magna aliqua.hi there is sso good team us.</p>
    </div>

     <div class="row">
        <div class="col span_1_of_4 max">
            <svg class="radial-progress skill-web" data-percentage="90" viewBox="0 0 80 80">
              <circle class="incomplete" cx="40" cy="40" r="35"></circle>
              <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
              <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">90%</text>
             </svg>
             <h3>Web Design</h3>
        </div>
    </div>
    
 
    <div class="row">
        <div class="col span_1_of_4 max">
            <svg class="radial-progress html-css" data-percentage="75" viewBox="0 0 80 80">
              <circle class="incomplete" cx="40" cy="40" r="35"></circle>
              <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
              <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">75%</text>
             </svg>
             <h3>HTML / CSS</h3>
        </div>
    </div>
     <div class="row">
        <div class="col span_1_of_4 max">
            <svg class="radial-progress photo-css" data-percentage="70" viewBox="0 0 80 80">
              <circle class="incomplete" cx="40" cy="40" r="35"></circle>
              <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
              <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">70%</text>
             </svg>
             <h3>GRAPHIC DESIGN</h3>
        </div>
    </div>
     <div class="row">
        <div class="col span_1_of_4 max">
            <svg class="radial-progress Ux-Ui" data-percentage="85" viewBox="0 0 80 80">
              <circle class="incomplete" cx="40" cy="40" r="35"></circle>
              <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
              <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">85%</text>
             </svg>
             <h3>UI / UX</h3>
        </div>
    </div>
     
</section>

<!--PORTPOLIO SECTION-->
<section class="portfolio-section clearfix " id="PortFolio">
    <div class="row">
        <h2>OUR PORTFOLIO</h2>
        <p class="textmart">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet
         consectetur, adipisci velit, sed quia non numquam.you are so good ata point.helloow lorem come on the pitch,begining on the pitch</p>
    </div>
   <div class="row">
       <div class="portfolio-filter">
           <button type="button" data-filter="all">all</button>
           <button type="button" data-filter=".web">web</button>
           <button type="button" data-filter=".apps">apps</button>
           <button type="button" data-filter=".icons">icons</button>
       </div>
   </div>
   
   <div class="row container">
       <div class="col mix apps span_1_of_2 max">
          <img src="Resurce/img/portfolio1.png" class="img-class" alt="">
          <h4>Isometric Perspective Mock-Up</h4>
       </div>
   
   
       <div class="col mix apps web span_1_of_2 max">
          <img src="Resurce/img/portfolio2.png" class="img-class" alt="">
          <h4>Time Zone App UI</h4>
       </div>
  
    
       <div class="col  mix icons span_1_of_2 max">
          <img src="Resurce/img/portfolio3.png" class="img-class" alt="">
          <h4>Viro Media Players UI</h4>
       </div>
  
    
       <div class="col mix apps icons web apps span_1_of_2 max">
          <img src="Resurce/img/portfolio4.png" class="img-class" alt="">
          <h4>Blog / Magazine Flat UI Kit</h4>
       </div>
  
  <div class="row">
      <a href="" class="btn btn-hero">LOAD MORE PROJECTS</a>
  </div>
  </div>
 
</section>


<!--PORTPOLIO SECTION-->


<!-- Testimonial SECTION Start-->

<section class="section-testimonial clearfix" id="Testimonial" >
    <div class="row">
        <h2>WHAT POEPLE SAY ABOUT US</h2>
        <p class="textmart">Our clients love us!</p>    
    </div>
    <div class="row">
        <div class="col span_1_of_2 max">
           <div class="hellow-review">
            <img src="Resurce/img/1.jpg" class="img" alt="clint-photo">
            </div>
            <div class="hellow-photo">
                <p class="small">“Nullam dapibus blandit orci, viverra gravida dui lobortis eget. Maecenas fringilla urna eu nisl scelerisque.hi lorem we are so happy with  it</p>
            
                <h3>Chanel Iman</h3>
                <span class="role">CEO of Pinterest</span>
            </div>
        </div>
         <div class="col span_1_of_2 max">
           <div class="hellow-review">
            <img src="Resurce/img/2.jpg" class="img" alt="clint-photo">
            </div>
            <div class="hellow-photo">
                <p class="texmart">“Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In condimentum facilisis porta.hi lorem we arr so happy with this happend in area”</p>
                <h3>Founder of Instagram.</h3>
                <span class="role">ADRIANA LIMA</span>
            </div>
        </div> 
         <div class="col span_1_of_2 max">
           <div class="hellow-review">
            <img src="Resurce/img/3.jpg" class="img"  alt="clint-photo">
            </div>
            <div class="hellow-photo">
                <p class="texmart">“Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In condimentum facilisis porta.hu lorem we are so happy with this attachment”</p>
                <h3>ANNE HATHAWAY</h3>
                <span class="role">Lead Designer at Behance</span>
            </div>
        </div> 
         <div class="col span_1_of_2 max">
           <div class="hellow-review">
            <img src="Resurce/img/4.jpg" class="img" alt="clint-photo">
            </div>
            <div class="hellow-photo">
                <p class="texmart">“Phasellus non purus vel arcu tempor commodo. Fusce semper, purus vel luctus molestie, risus sem cursus neque. nice and greddy”.</p>
                <h3>EMMA STONE</h3>
                <span class="role">Co-Founder of Shazad</span>
            </div>
        </div> 
    </div>
</section>


<!-- Testimonial SECTION eND-->
   <!-- Contact SECTION Start-->
   
   <section class="contact-section clearfix" id="Contact" >
       <div class="row">
           <h2>GET IN TOUCH</h2>
           <p class="textmart">1600 Pennsylvania Ave NW, Washington, DC 20500, United States of America. Tel: (202) 456-1111.</p>
       </div>
          <div class="row">
              <form action="https://formspree.io/mahabubalam2k10@gmail.com" method="POST">
              <div class="row">
                  <div class="col span_1_of_2">
                      <input type="text" name="Name" placeholder="Your Name *" required>
                  </div>
                  <div class="col span_1_of_2">
                        <input type="email" name="Email" placeholder="Your Email*" required>
                  </div>
                   <div class="row">
                 <textarea name="Message"  cols="30" placeholder="Your Message*" rows="10" required></textarea>
             </div>
                <div class="row human">
                 <input type="Submit" value="Send Message" class="btn btn-submit">
             </div>
              </div>
             
           
              </form>
          </div>
         
          
   </section>

   
   <!-- Contact SECTION eND-->
   <!-- Footer SECTION Start-->
   
   <section class="footer-section clearfix">
       <div class="row">
           <ul>
               <li><a href="#">Facebook</a></li>
               <li><a href="#">Twitter</a></li>
               <li><a href="#">Google</a></li>
               <li><a href="#">LinkedIn</a></li>
               <li><a href="#">Behance</a></li>
               <li><a href="#">Dribbble</a></li>
               <li><a href="#">Github</a></li>
               
           </ul>
       </div>
   </section>
   
   
   
   
   
   <!-- Footeer SECTION eND-->

   
   
      
   
   
    
   
  
 
<!-- js script-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
 <script src="Vendors/js/html5shiv-printshiv.min.js"></script>
 <script src="Vendors/js/respond.min.js"></script> 
  <script src="Vendors/js/selectivizr.js"></script>
  <script src="Vendors/js/jquery.waypoints.min.js"></script>
 
  <script src="Vendors/js/mixitup.min.js"></script>
  
  <script src="Resurce/js/main.js"></script>
  
  
  
 
</body>
</html>